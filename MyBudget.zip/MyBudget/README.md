# My Budget
Spreadsheet-style monthly budget: labeled rows, live totals, multiple sheets. Kotlin + Jetpack Compose + Room. Fully offline.

Open this folder in Android Studio (Koala or newer), let Gradle sync, and press Run.
