package com.example.mybudget.ui

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowDropDown
import androidx.compose.material.icons.filled.MoreVert
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Checkbox
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.mybudget.data.Item

private sealed interface Dialog {
    data object NewSheet : Dialog
    data object RenameSheet : Dialog
    data object DuplicateSheet : Dialog
    data object DeleteSheet : Dialog
    data class EditItem(val item: Item?) : Dialog
}

private val Green = Color(0xFF2E9E5B)
private val Red = Color(0xFFD64545)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun BudgetScreen(vm: BudgetViewModel = viewModel()) {
    val sheets by vm.sheets.collectAsStateWithLifecycle()
    val sheet by vm.currentSheet.collectAsStateWithLifecycle()
    val items by vm.items.collectAsStateWithLifecycle()
    val totals by vm.totals.collectAsStateWithLifecycle()

    var dialog by remember { mutableStateOf<Dialog?>(null) }
    var sheetMenu by remember { mutableStateOf(false) }
    var moreMenu by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Box {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.clickable { sheetMenu = true },
                        ) {
                            Text(sheet?.name ?: "", maxLines = 1)
                            Icon(Icons.Default.ArrowDropDown, contentDescription = "Switch sheet")
                        }
                        DropdownMenu(expanded = sheetMenu, onDismissRequest = { sheetMenu = false }) {
                            sheets.forEach { s ->
                                DropdownMenuItem(
                                    text = { Text(s.name) },
                                    onClick = { vm.selectSheet(s.id); sheetMenu = false },
                                )
                            }
                            HorizontalDivider()
                            DropdownMenuItem(
                                text = { Text("New sheet…") },
                                onClick = { sheetMenu = false; dialog = Dialog.NewSheet },
                            )
                        }
                    }
                },
                actions = {
                    Box {
                        IconButton(onClick = { moreMenu = true }) {
                            Icon(Icons.Default.MoreVert, contentDescription = "More")
                        }
                        DropdownMenu(expanded = moreMenu, onDismissRequest = { moreMenu = false }) {
                            DropdownMenuItem(
                                text = { Text("Rename") },
                                onClick = { moreMenu = false; dialog = Dialog.RenameSheet },
                            )
                            DropdownMenuItem(
                                text = { Text("Duplicate (next month)") },
                                onClick = { moreMenu = false; dialog = Dialog.DuplicateSheet },
                            )
                            DropdownMenuItem(
                                text = { Text("Delete sheet") },
                                onClick = { moreMenu = false; dialog = Dialog.DeleteSheet },
                            )
                        }
                    }
                },
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = { dialog = Dialog.EditItem(null) }) {
                Icon(Icons.Default.Add, contentDescription = "Add row")
            }
        },
        bottomBar = { TotalsBar(totals) },
    ) { padding ->
        if (items.isEmpty()) {
            Box(Modifier.padding(padding).fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No rows yet. Tap + to add income or expenses.")
            }
        } else {
            LazyColumn(Modifier.padding(padding).fillMaxSize()) {
                items(items, key = { it.id }) { item ->
                    ItemRow(
                        item = item,
                        onClick = { dialog = Dialog.EditItem(item) },
                        onToggleDone = { vm.toggleDone(item) },
                    )
                    HorizontalDivider()
                }
                item { Spacer(Modifier.padding(bottom = 80.dp)) }
            }
        }
    }

    when (val d = dialog) {
        null -> Unit
        Dialog.NewSheet -> NameDialog("New sheet", "", { vm.createSheet(it); dialog = null }, { dialog = null })
        Dialog.RenameSheet -> NameDialog(
            "Rename sheet", sheet?.name ?: "", { vm.renameSheet(it); dialog = null }, { dialog = null },
        )
        Dialog.DuplicateSheet -> NameDialog(
            "Duplicate as…", "", { vm.duplicateSheet(it); dialog = null }, { dialog = null },
        )
        Dialog.DeleteSheet -> AlertDialog(
            onDismissRequest = { dialog = null },
            title = { Text("Delete \"${sheet?.name ?: ""}\"?") },
            text = { Text("This removes the sheet and all its rows.") },
            confirmButton = { TextButton(onClick = { vm.deleteSheet(); dialog = null }) { Text("Delete") } },
            dismissButton = { TextButton(onClick = { dialog = null }) { Text("Cancel") } },
        )
        is Dialog.EditItem -> ItemDialog(
            existing = d.item,
            onSave = { label, cents, income, counted ->
                vm.saveItem(d.item, label, cents, income, counted); dialog = null
            },
            onDelete = { d.item?.let { vm.deleteItem(it) }; dialog = null },
            onDismiss = { dialog = null },
        )
    }
}

@Composable
private fun ItemRow(item: Item, onClick: () -> Unit, onToggleDone: () -> Unit) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        modifier = Modifier
            .fillMaxWidth()
            .clickable(onClick = onClick)
            .alpha(if (item.counted) 1f else 0.45f)
            .padding(horizontal = 8.dp, vertical = 4.dp),
    ) {
        Checkbox(checked = item.done, onCheckedChange = { onToggleDone() })
        Text(
            text = item.label,
            style = MaterialTheme.typography.bodyLarge,
            textDecoration = if (item.done) TextDecoration.LineThrough else null,
            modifier = Modifier.weight(1f),
        )
        Text(
            text = (if (item.isIncome) "+" else "−") + formatMoney(item.amountCents),
            color = if (item.isIncome) Green else MaterialTheme.colorScheme.onSurface,
            fontWeight = FontWeight.Medium,
            modifier = Modifier.padding(end = 8.dp),
        )
    }
}

@Composable
private fun TotalsBar(totals: Totals) {
    Surface(tonalElevation = 3.dp, shadowElevation = 6.dp) {
        Row(
            horizontalArrangement = Arrangement.SpaceEvenly,
            modifier = Modifier
                .fillMaxWidth()
                .navigationBarsPadding()
                .padding(vertical = 12.dp),
        ) {
            TotalCell("Income", formatMoney(totals.income), Green)
            TotalCell("Expenses", formatMoney(totals.expenses), MaterialTheme.colorScheme.onSurface)
            TotalCell("Left", formatMoney(totals.left), if (totals.left < 0) Red else Green)
        }
    }
}

@Composable
private fun TotalCell(label: String, value: String, color: Color) {
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
        Text(label, style = MaterialTheme.typography.labelMedium)
        Text(value, color = color, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.titleMedium)
    }
}

@Composable
private fun NameDialog(title: String, initial: String, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(initial) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(title) },
        text = { OutlinedTextField(value = name, onValueChange = { name = it }, singleLine = true, label = { Text("Name") }) },
        confirmButton = { TextButton(enabled = name.isNotBlank(), onClick = { onConfirm(name) }) { Text("OK") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}

@Composable
private fun ItemDialog(
    existing: Item?,
    onSave: (label: String, cents: Long, isIncome: Boolean, counted: Boolean) -> Unit,
    onDelete: () -> Unit,
    onDismiss: () -> Unit,
) {
    var label by remember { mutableStateOf(existing?.label ?: "") }
    var amount by remember { mutableStateOf(existing?.let { centsToInput(it.amountCents) } ?: "") }
    var isIncome by remember { mutableStateOf(existing?.isIncome ?: false) }
    var counted by remember { mutableStateOf(existing?.counted ?: true) }
    val cents = parseCents(amount)

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (existing == null) "Add row" else "Edit row") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = label, onValueChange = { label = it },
                    singleLine = true, label = { Text("Label") },
                )
                OutlinedTextField(
                    value = amount, onValueChange = { amount = it },
                    singleLine = true, label = { Text("Amount") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                    isError = amount.isNotEmpty() && cents == null,
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = !isIncome, onClick = { isIncome = false }, label = { Text("Expense") })
                    FilterChip(selected = isIncome, onClick = { isIncome = true }, label = { Text("Income") })
                }
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("Count in totals", modifier = Modifier.weight(1f))
                    Switch(checked = counted, onCheckedChange = { counted = it })
                }
                if (existing != null) {
                    TextButton(onClick = onDelete) { Text("Delete row", color = Red) }
                }
            }
        },
        confirmButton = {
            TextButton(
                enabled = label.isNotBlank() && cents != null,
                onClick = { onSave(label, cents!!, isIncome, counted) },
            ) { Text("Save") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Cancel") } },
    )
}
