package com.example.mybudget

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.ui.graphics.Color
import com.example.mybudget.ui.BudgetScreen

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            val orange = Color(0xFFF28C00)
            MaterialTheme(
                colorScheme = if (isSystemInDarkTheme()) darkColorScheme(primary = orange)
                else lightColorScheme(primary = orange)
            ) {
                BudgetScreen()
            }
        }
    }
}
