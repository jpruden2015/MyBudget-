package com.example.mybudget.ui

import java.math.BigDecimal
import java.math.RoundingMode
import java.text.NumberFormat

fun formatMoney(cents: Long): String =
    NumberFormat.getCurrencyInstance().format(cents / 100.0)

/** Parses user input like "1,234.50" or "12,5" into cents. Returns null if invalid or negative. */
fun parseCents(input: String): Long? {
    var s = input.trim().replace(" ", "")
    if (s.isEmpty()) return null
    s = if (s.contains('.')) s.replace(",", "") else s.replace(',', '.')
    val value = s.toBigDecimalOrNull() ?: return null
    if (value < BigDecimal.ZERO) return null
    return value.movePointRight(2).setScale(0, RoundingMode.HALF_UP).toLong()
}

fun centsToInput(cents: Long): String =
    BigDecimal(cents).movePointLeft(2).setScale(2).toPlainString()
