package com.example.mybudget.data

import androidx.room.Entity
import androidx.room.ForeignKey
import androidx.room.Index
import androidx.room.PrimaryKey

@Entity(tableName = "sheets")
data class Sheet(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
)

@Entity(
    tableName = "items",
    foreignKeys = [
        ForeignKey(
            entity = Sheet::class,
            parentColumns = ["id"],
            childColumns = ["sheetId"],
            onDelete = ForeignKey.CASCADE,
        )
    ],
    indices = [Index("sheetId")],
)
data class Item(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sheetId: Long,
    val label: String,
    val amountCents: Long,
    val isIncome: Boolean,
    val done: Boolean = false,
    val counted: Boolean = true,
)
