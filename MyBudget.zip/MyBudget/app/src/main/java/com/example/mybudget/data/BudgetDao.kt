package com.example.mybudget.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Transaction
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
abstract class BudgetDao {
    @Query("SELECT * FROM sheets ORDER BY id")
    abstract fun observeSheets(): Flow<List<Sheet>>

    @Query("SELECT * FROM items WHERE sheetId = :sheetId ORDER BY id")
    abstract fun observeItems(sheetId: Long): Flow<List<Item>>

    @Query("SELECT * FROM items WHERE sheetId = :sheetId ORDER BY id")
    abstract suspend fun getItems(sheetId: Long): List<Item>

    @Query("SELECT COUNT(*) FROM sheets")
    abstract suspend fun sheetCount(): Int

    @Insert abstract suspend fun insertSheet(sheet: Sheet): Long
    @Update abstract suspend fun updateSheet(sheet: Sheet)
    @Delete abstract suspend fun deleteSheet(sheet: Sheet)

    @Insert abstract suspend fun insertItem(item: Item): Long
    @Insert abstract suspend fun insertItems(items: List<Item>)
    @Update abstract suspend fun updateItem(item: Item)
    @Delete abstract suspend fun deleteItem(item: Item)

    /** Copies every row into a new sheet, with "paid" checks cleared. */
    @Transaction
    open suspend fun duplicateSheet(sourceId: Long, name: String): Long {
        val newId = insertSheet(Sheet(name = name))
        insertItems(getItems(sourceId).map { it.copy(id = 0, sheetId = newId, done = false) })
        return newId
    }
}
