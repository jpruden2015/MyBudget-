package com.example.mybudget.ui

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.mybudget.data.AppDatabase
import com.example.mybudget.data.Item
import com.example.mybudget.data.Sheet
import kotlinx.coroutines.ExperimentalCoroutinesApi
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.flow.flatMapLatest
import kotlinx.coroutines.flow.flowOf
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

data class Totals(val income: Long = 0, val expenses: Long = 0) {
    val left: Long get() = income - expenses
}

@OptIn(ExperimentalCoroutinesApi::class)
class BudgetViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = AppDatabase.get(app).dao()
    private val selectedId = MutableStateFlow<Long?>(null)
    private val sharing = SharingStarted.WhileSubscribed(5_000)

    val sheets: StateFlow<List<Sheet>> =
        dao.observeSheets().stateIn(viewModelScope, sharing, emptyList())

    val currentSheet: StateFlow<Sheet?> =
        combine(sheets, selectedId) { list, id -> list.firstOrNull { it.id == id } ?: list.firstOrNull() }
            .stateIn(viewModelScope, sharing, null)

    val items: StateFlow<List<Item>> =
        currentSheet.map { it?.id }
            .distinctUntilChanged()
            .flatMapLatest { id -> if (id == null) flowOf(emptyList()) else dao.observeItems(id) }
            .stateIn(viewModelScope, sharing, emptyList())

    val totals: StateFlow<Totals> =
        items.map { list ->
            val counted = list.filter { it.counted }
            Totals(
                income = counted.filter { it.isIncome }.sumOf { it.amountCents },
                expenses = counted.filter { !it.isIncome }.sumOf { it.amountCents },
            )
        }.stateIn(viewModelScope, sharing, Totals())

    init {
        viewModelScope.launch { ensureASheetExists() }
    }

    private suspend fun ensureASheetExists() {
        if (dao.sheetCount() == 0) {
            dao.insertSheet(Sheet(name = SimpleDateFormat("MMMM yyyy", Locale.getDefault()).format(Date())))
        }
    }

    fun selectSheet(id: Long) { selectedId.value = id }

    fun createSheet(name: String) = viewModelScope.launch {
        selectedId.value = dao.insertSheet(Sheet(name = name.trim()))
    }

    fun renameSheet(name: String) = viewModelScope.launch {
        currentSheet.value?.let { dao.updateSheet(it.copy(name = name.trim())) }
    }

    fun duplicateSheet(name: String) = viewModelScope.launch {
        currentSheet.value?.let { selectedId.value = dao.duplicateSheet(it.id, name.trim()) }
    }

    fun deleteSheet() = viewModelScope.launch {
        currentSheet.value?.let { dao.deleteSheet(it) }
        selectedId.value = null
        ensureASheetExists()
    }

    fun saveItem(existing: Item?, label: String, cents: Long, isIncome: Boolean, counted: Boolean) =
        viewModelScope.launch {
            if (existing == null) {
                val sheetId = currentSheet.value?.id ?: return@launch
                dao.insertItem(
                    Item(sheetId = sheetId, label = label.trim(), amountCents = cents, isIncome = isIncome, counted = counted)
                )
            } else {
                dao.updateItem(
                    existing.copy(label = label.trim(), amountCents = cents, isIncome = isIncome, counted = counted)
                )
            }
        }

    fun toggleDone(item: Item) = viewModelScope.launch { dao.updateItem(item.copy(done = !item.done)) }

    fun deleteItem(item: Item) = viewModelScope.launch { dao.deleteItem(item) }
}
